import * as React from "react";
import { useEffect, useState } from "react";
import axios from 'axios';

export interface DetailProps {
  itemId: string;
}

export const DetailControl = ({ itemId }: DetailProps)  => {
  const [customer, setCustomer] = useState("");
  const [img, setImg] = useState();

  const imageUrl = "https://cdn.pixabay.com/photo/2022/04/04/12/58/customer-support-7111206_1280.png";
  const fetchImage = async () => {
    const res = await fetch(imageUrl);
    const imageBlob = await res.blob();
    const imageObjectURL: any = URL.createObjectURL(imageBlob);
    setImg(imageObjectURL);
  };


  useEffect(() => {
    if (itemId === "") {
      return;
    }
    const getCustomerDetails = async () => {
      try {
        const response = await axios.get("https://services.odata.org/V3/Northwind/Northwind.svc/Customers('" + itemId + "')" );
        setCustomer(response.data);
      } catch (error) {
        console.error('Error fetching customers:', error);
      }
    };

    getCustomerDetails();
    fetchImage();
  }, [itemId]);


  return (
    <div >
      <img src={img} width="200" height="200" alt="Click on a customer on left" />
      <div >{customer[("CustomerID") as any]}</div>
      <div >{customer[('ContactName')as any ]}</div>
      <div >{customer[('ContactTitle') as any]}</div>
      <div className="card-body">
      </div>
    </div>
  );
};
