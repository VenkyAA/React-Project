import React, { useEffect, useState } from "react";
import { products } from "./store";
import axios from 'axios';
import "./styles.css";

interface MasterControlProps {
  onClick: (itemId: string) => void;
}

export const MasterControl = ({ onClick }: MasterControlProps) => {
  const [img, setImg] = useState();
  const [customers, setCustomers] = useState([]);
  const imageUrl = "https://assets-global.website-files.com/62d697043195b8fda77632fa/6401ff5cc602ef5d06b4069b_%20Customer-centric%20marketing.jpeg";
  const fetchImage = async () => {
    const res = await fetch(imageUrl);
    const imageBlob = await res.blob();
    const imageObjectURL: any = URL.createObjectURL(imageBlob);
    setImg(imageObjectURL);
  };


  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await axios.get('https://services.odata.org/V3/Northwind/Northwind.svc/Customers');
        setCustomers(response.data.value);
      } catch (error) {
        console.error('Error fetching customers:', error);
      }
    };

    fetchCustomers();
    fetchImage();
  }, []);


  return (
    <table className="table table-sm table-hover">
      <tbody>
        {customers.map(customer => (
          <tr className="border" key={customer['CustomerID']} onClick={() => onClick(customer['CustomerID'])}>
             <img src={img} width="40" height="50" alt="icons" />
            <label className="itemPadding"> {customer['ContactName']}</label><br></br>
            <br></br>
          </tr>
        ))}
      </tbody>
    </table>
  );
};
