import * as React from "react";
import { render } from "react-dom";
import { MasterDetailControl } from "./MasterDetailControl";
import "./styles.css";

function App() {
  return <MasterDetailControl />;
}

const rootElement = document.getElementById("root");
render(<App />, rootElement);
