import * as React from "react";
import { MasterControl } from "./MasterControl";
import { DetailControl } from "./DetailControl";
import "./styles.css";


export const MasterDetailControl = () => {
  const [itemId, setItemId] = React.useState("");

  const handleClick = (itemId: string) => {
    setItemId(itemId);
  };

 

  return (
    <div className="d-flex p-2">
      <div >
      <label>  Customers</label>
        <MasterControl onClick={handleClick} />
      </div>
      <div className="flex-fill detailPadding">
        <label className="detailHeaderBorder">  Customer Details</label>
        <DetailControl itemId={itemId} />
      </div>
    </div>
  );
};
