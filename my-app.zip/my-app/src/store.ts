export const products = [
  {
    id: "C01",
    name: "customer1",
    adress: "Telangana",
    title: "Sales Manager",
    image:"./images/cust1.jpeg",
    details: "Customer1 Details"
  },
  {
    id: "C02",
    name: "customer2",
    adress: "Delhi",
    title: "Marketing Manager",
    image:"./images/cust2.jpeg",
    details: "Customer2 Details"
  }
];
