import * as React from "react";
import { render } from "react-dom";
import "./styles.css";
import { MasterDetailControl } from "./MasterDetailControl";

const handleClick = (itemId: string) => {
  //setItemId(itemId);
};

function App() {
  return  <MasterDetailControl />;
}

const rootElement = document.getElementById("root");
render(<App />, rootElement);

export default App;
